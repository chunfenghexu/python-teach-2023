public class Square extends Shape{
    void draw(){
        System.out.println("Square-draw");
    }
    void erase(){
        System.out.println("Square-erase");
    }
}