import java.util.ArrayList;

public class Lender extends Individual{
    private int MonthlyIncome;
    private ArrayList<Loan> loans = new ArrayList<Loan>();
    public Lender(){}
    public Lender(int ID , String name , int MonthlyIncome){
        super(ID,name);
        this.MonthlyIncome = MonthlyIncome;
    }
    public boolean equals(Object a){
        // 判断是不是我能比较的对象
        if(a instanceof Lender){
            // 向下转型
            Lender new_a = (Lender)a;
            return this.getID() == new_a.getID() &&
                    this.getName().equals(new_a.getName()) &&
                    this.getMonthlyIncome() == new_a.getMonthlyIncome();
        }
        return false;
    }
    public int getMonthlyIncome() {
        return MonthlyIncome;
    }

    public void setMonthlyIncome(int monthlyIncome) {
        MonthlyIncome = monthlyIncome;
    }
    public String toString(){
        return super.toString() + "| MonthlyIncome:" + this.MonthlyIncome;
    }

    public static void main(String[] args) {
        // ==  对于基本数据类型  ， 对于类类型
        Lender a = new Lender(1,"lv",0);
        Lender b = new Lender(1,"lv",0);
        if ( a == b ){System.out.println(" a == b ");}
        if ( a.equals(b) ){System.out.println("a equals b");}
        // equals
        // String 类型 关于相等 有一个小坑
        // int / boolean 小写的都是基本数据类型 ； 首字母大写的都是类类型
        //String s1 = "aaa"; // 字面量写法
        //String s2 = "aaa";
        String s1 = new String("aaa");
        String s2 = new String("aaa");
        if( s1 == s2){System.out.println("s1 == s2");}
        if( s1.equals(s2) ){System.out.println("s1 equals s2");}
    }
}
