public class Shape{
    void draw(){

    }
    void erase(){

    } 
}

