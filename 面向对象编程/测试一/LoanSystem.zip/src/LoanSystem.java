import java.io.*;
import java.util.ArrayList;

public class LoanSystem {
    // 一对多关系的构建，是给关联关系的发出者，添加列表属性
    private static ArrayList<Borrower> borrowers = new ArrayList<Borrower>();
    private static ArrayList<Lender> lenders = new ArrayList<Lender>();
    private static ArrayList<Loan> loans = new ArrayList<Loan>();
    // 一对一关系的构建
    private static Borrower borrower = new Borrower();
    // java IO 编程
    private static BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in)); // System.in 从默认的标准输入设备中读 （键盘）
    private static PrintWriter stdErr = new PrintWriter(System.err,true);
    private static PrintWriter stdOut = new PrintWriter(System.out,true);
    public static void addLender(){
        try {
            stdErr.println("请输入ID >");
            int id = Integer.parseInt(stdIn.readLine());
            stdErr.println("请输入name >");
            String name = stdIn.readLine();
            stdErr.println("请输入monthlyIncome >");
            int monthlyIncome = Integer.parseInt(stdIn.readLine());
            // 数据准备好了，要开始添加了
            LoanSystem.lenders.add(
                    new Lender(id,name,monthlyIncome));
            stdErr.println("add Lender OK!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void lookUpLenderById(){
        // 这个应该如何实现呢？思考一下
        try {
            stdErr.println("请输入ID >");
            int id = Integer.parseInt(stdIn.readLine());
            for(int i = 0 ; i < lenders.size() ; i++){
                if(lenders.get(i).getID() == id){
                    stdErr.println("找到了！");
                    stdErr.println(lenders.get(i).toString());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    public static void removeLender(){
        try {
            stdErr.println("请输入ID >");
            int id = Integer.parseInt(stdIn.readLine());
            for(int i = 0 ; i < lenders.size() ; i++){
                if(lenders.get(i).getID() == id){
                    stdErr.println("找到了！");
                    lenders.remove(i);
                    stdErr.println("删掉了");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) throws IOException {
        String caiDan = "[0] exit" + "\n" +
                        "[1] add a lender into the system" + "\n" +
                        "[2] look up a lender given an ID" +"\n" +
                        "[3] remove a lender from the system given an ID";
        stdErr.println("请选择以下菜单中的功能 > \n");
        stdErr.println(caiDan);
        int choice = Integer.parseInt(stdIn.readLine());
        while(choice != 0){
            switch (choice){
                case 1 :
                    stdOut.println("do 1");
                    addLender();
                    break;
                case 2 :
                    stdOut.println("do 2");
                    lookUpLenderById();
                    break;
                case 3 :
                    stdOut.println("do 3");
                    removeLender();
                    break;
            }
            stdErr.println(caiDan);
            choice = Integer.parseInt(stdIn.readLine());
        }
    }
}
